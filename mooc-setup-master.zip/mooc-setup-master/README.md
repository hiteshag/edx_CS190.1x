# mooc-setup
Information for setting up for the Spark MOOC, and lab assignments for the course.
